(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["js/admin/dashboard"],{

/***/ "./Resources/assets/js/pages/Dashboard/index.js":
/*!******************************************************!*\
  !*** ./Resources/assets/js/pages/Dashboard/index.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/components */ "./Resources/assets/js/components/index.js");



var Dashboard = function Dashboard() {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components__WEBPACK_IMPORTED_MODULE_1__["Page"], {
    title: 'Dashboard'
  });
};

/* harmony default export */ __webpack_exports__["default"] = (Dashboard);

/***/ })

}]);